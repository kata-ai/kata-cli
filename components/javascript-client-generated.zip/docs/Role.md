# Zaun.Role

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**abilities** | **Object** |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `user` (value: `"user"`)

* `team` (value: `"team"`)

* `bot` (value: `"bot"`)




