# Zaun.Flow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**fallback** | **Boolean** |  | [optional] 
**priority** | **Number** |  | [optional] 
**expire** | **Number** |  | [optional] 
**_volatile** | **Boolean** |  | [optional] 
**intents** | [**FlowIntents**](FlowIntents.md) |  | [optional] 
**states** | [**FlowStates**](FlowStates.md) |  | [optional] 
**stateMapper** | **String** |  | [optional] 
**stateActions** | [**FlowStateActions**](FlowStateActions.md) |  | [optional] 
**actions** | [**FlowActions**](FlowActions.md) |  | [optional] 
**methods** | [**FlowMethods**](FlowMethods.md) |  | [optional] 
**nlus** | [**FlowNlus**](FlowNlus.md) |  | [optional] 


