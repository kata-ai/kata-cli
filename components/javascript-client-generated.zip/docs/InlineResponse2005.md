# Zaun.InlineResponse2005

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**team** | [**Team**](Team.md) |  | [optional] 
**members** | [**[InlineResponse2005Members]**](InlineResponse2005Members.md) |  | [optional] 


