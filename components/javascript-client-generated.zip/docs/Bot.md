# Zaun.Bot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | 
**name** | **String** |  | 
**version** | **String** |  | [optional] 
**desc** | **String** |  | [optional] 
**lang** | **String** |  | [optional] 
**timezone** | **Number** |  | [optional] 
**flows** | **Object** |  | [optional] 
**nlus** | **Object** |  | [optional] 
**methods** | **Object** |  | [optional] 
**config** | **Object** |  | [optional] 


