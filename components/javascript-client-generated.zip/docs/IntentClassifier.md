# Zaun.IntentClassifier

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nlu** | **String** |  | [optional] 
**hint** | **String** |  | [optional] 
**match** | **String** |  | [optional] 
**process** | **String** |  | [optional] 
**options** | **Object** |  | [optional] 


