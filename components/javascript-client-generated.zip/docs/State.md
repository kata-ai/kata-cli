# Zaun.State

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**initial** | **Boolean** |  | [optional] 
**_float** | [**StateTransition**](StateTransition.md) |  | [optional] 
**action** | [**StateAction**](StateAction.md) |  | [optional] 
**enter** | **String** |  | [optional] 
**transit** | **String** |  | [optional] 
**exit** | **String** |  | [optional] 
**end** | **Boolean** |  | [optional] 
**transitions** | [**StateTransitions**](StateTransitions.md) |  | [optional] 


