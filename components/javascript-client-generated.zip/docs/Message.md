# Zaun.Message

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**content** | **String** |  | [optional] 
**payload** | **Object** |  | [optional] 
**id** | **String** |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `text` (value: `"text"`)

* `data` (value: `"data"`)

* `command` (value: `"command"`)




