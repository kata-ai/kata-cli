# Zaun.ResponseMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**action** | **String** |  | [optional] 
**content** | **String** |  | [optional] 
**payload** | **Object** |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `text` (value: `"text"`)

* `data` (value: `"data"`)

* `result` (value: `"result"`)

* `command` (value: `"command"`)




