# Zaun.Method

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **String** |  | [optional] 
**entry** | **String** |  | [optional] 


