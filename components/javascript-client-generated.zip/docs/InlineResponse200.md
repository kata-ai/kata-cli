# Zaun.InlineResponse200

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**versions** | **[String]** |  | [optional] 
**latest** | **String** |  | [optional] 


