# Zaun.FlowIntents

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**Intent**](Intent.md) |  | [optional] 


