# Zaun.Deployment

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**botId** | **String** |  | [optional] 
**botVersion** | **String** |  | [optional] 
**channels** | **Object** |  | [optional] 


