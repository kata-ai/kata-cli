# Zaun.FlowNlus

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**Nlu**](Nlu.md) |  | [optional] 


