# Zaun.Conversation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **String** |  | [optional] 
**message** | **Object** |  | [optional] 
**dataKey** | **String** |  | [optional] 


