# Zaun.InlineResponse2004

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | **Number** |  | [optional] 
**limit** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 
**items** | [**[User]**](User.md) |  | [optional] 


