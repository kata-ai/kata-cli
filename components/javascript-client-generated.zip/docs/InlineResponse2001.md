# Zaun.InlineResponse2001

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | **Number** |  | [optional] 
**limit** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 
**items** | [**[Deployment]**](Deployment.md) |  | [optional] 


