# Zaun.Token

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**label** | **String** |  | [optional] 
**userId** | **String** |  | [optional] 
**teamId** | **String** |  | [optional] 
**botId** | **String** |  | [optional] 
**roleId** | **String** |  | [optional] 
**expire** | **Number** |  | [optional] 


