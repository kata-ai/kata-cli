# Zaun.StateTransition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**condition** | **String** |  | [optional] 
**fallback** | **Boolean** |  | [optional] 
**priority** | **Number** |  | [optional] 
**mapping** | **String** |  | [optional] 


