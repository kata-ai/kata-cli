# Zaun.Session

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**channelId** | **String** |  | [optional] 
**deploymentId** | **String** |  | [optional] 
**dataKey** | **String** |  | [optional] 
**states** | **String** |  | [optional] 
**contexes** | **String** |  | [optional] 
**history** | [**[SessionHistory]**](SessionHistory.md) |  | [optional] 
**current** | **String** |  | [optional] 
**timestamp** | **Number** |  | [optional] 
**meta** | **Object** |  | [optional] 
**data** | **Object** |  | [optional] 


