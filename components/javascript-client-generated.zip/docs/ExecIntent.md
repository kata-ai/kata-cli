# Zaun.ExecIntent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flow** | **String** |  | [optional] 
**intent** | **String** |  | [optional] 
**message** | [**Message**](Message.md) |  | [optional] 
**context** | **Object** |  | [optional] 
**data** | **Object** |  | [optional] 


