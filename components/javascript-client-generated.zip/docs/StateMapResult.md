# Zaun.StateMapResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**state** | **String** |  | [optional] 
**data** | **Object** |  | [optional] 
**context** | **Object** |  | [optional] 
**end** | **Boolean** |  | [optional] 


