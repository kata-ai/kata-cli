# Zaun.Response

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**refId** | **String** |  | [optional] 
**flow** | **String** |  | [optional] 


