# Zaun.CachesApi

All URIs are relative to *http://zaun.katalabs.io/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**cachesDelete**](CachesApi.md#cachesDelete) | **DELETE** /caches | Clear diaenne&#39;s caches


<a name="cachesDelete"></a>
# **cachesDelete**
> cachesDelete()

Clear diaenne&#39;s caches

### Example
```javascript
var Zaun = require('zaun');
var defaultClient = Zaun.ApiClient.default;

// Configure API key authorization: Bearer
var Bearer = defaultClient.authentications['Bearer'];
Bearer.apiKey = 'YOUR API KEY';
// Uncomment the following line to set a prefix for the API key, e.g. "Token" (defaults to null)
//Bearer.apiKeyPrefix = 'Token';

var apiInstance = new Zaun.CachesApi();

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.cachesDelete(callback);
```

### Parameters
This endpoint does not need any parameter.

### Return type

null (empty response body)

### Authorization

[Bearer](../README.md#Bearer)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

