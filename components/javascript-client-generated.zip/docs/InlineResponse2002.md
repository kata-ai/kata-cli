# Zaun.InlineResponse2002

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | **Number** |  | [optional] 
**limit** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 
**items** | [**[Channel]**](Channel.md) |  | [optional] 


