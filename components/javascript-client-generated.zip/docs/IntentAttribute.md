# Zaun.IntentAttribute

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nlu** | **String** |  | [optional] 
**hint** | **String** |  | [optional] 
**path** | **String** |  | [optional] 
**process** | **String** |  | [optional] 
**options** | **Object** |  | [optional] 


