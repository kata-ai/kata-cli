# Zaun.StateTransitions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**StateTransition**](StateTransition.md) |  | [optional] 


