# Zaun.Team

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**teamname** | **String** |  | [optional] 
**profile** | **Object** |  | [optional] 


