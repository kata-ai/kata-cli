# Zaun.FlowActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**Action**](Action.md) |  | [optional] 


