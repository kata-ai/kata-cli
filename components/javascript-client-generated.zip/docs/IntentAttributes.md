# Zaun.IntentAttributes

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**IntentAttribute**](IntentAttribute.md) |  | [optional] 


