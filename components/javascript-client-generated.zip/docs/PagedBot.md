# Zaun.PagedBot

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | **Number** |  | [optional] 
**limit** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 
**items** | [**[Bot]**](Bot.md) |  | [optional] 


