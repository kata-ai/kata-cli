# Zaun.InlineResponse2005Members

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**userId** | **String** |  | [optional] 
**role** | **String** |  | [optional] 


<a name="RoleEnum"></a>
## Enum: RoleEnum


* `admin` (value: `"admin"`)

* `member` (value: `"member"`)




