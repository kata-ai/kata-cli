# Zaun.ExecStateMapper

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flow** | **String** |  | [optional] 
**state** | **String** |  | [optional] 
**message** | [**ProcessedMessage**](ProcessedMessage.md) |  | [optional] 
**context** | **Object** |  | [optional] 
**data** | **Object** |  | [optional] 


