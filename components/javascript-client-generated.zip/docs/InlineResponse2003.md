# Zaun.InlineResponse2003

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**page** | **Number** |  | [optional] 
**limit** | **Number** |  | [optional] 
**count** | **Number** |  | [optional] 
**total** | **Number** |  | [optional] 
**items** | [**[Role]**](Role.md) |  | [optional] 


