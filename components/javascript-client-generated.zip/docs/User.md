# Zaun.User

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**username** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**profile** | **Object** |  | [optional] 


