# Zaun.FlowStateActions

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**StateAction**](StateAction.md) |  | [optional] 


