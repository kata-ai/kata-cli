# Zaun.Channel

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **String** |  | [optional] 
**name** | **String** |  | [optional] 
**type** | **String** |  | [optional] 
**partnerChannelId** | **String** |  | [optional] 
**token** | **String** |  | [optional] 
**refreshToken** | **String** |  | [optional] 
**url** | **String** |  | [optional] 


<a name="TypeEnum"></a>
## Enum: TypeEnum


* `generic` (value: `"generic"`)

* `line` (value: `"line"`)

* `fbmessenger` (value: `"fbmessenger"`)




