# Zaun.ExecFlow

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flow** | **String** |  | [optional] 
**state** | **String** |  | [optional] 
**message** | [**Message**](Message.md) |  | [optional] 
**context** | **Object** |  | [optional] 
**data** | **Object** |  | [optional] 
**intent** | **String** |  | [optional] 


