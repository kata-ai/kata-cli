# Zaun.FlowProcessResult

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**intent** | **String** |  | [optional] 
**attributes** | **Object** |  | [optional] 
**responses** | [**[ResponseMessage]**](ResponseMessage.md) |  | [optional] 


