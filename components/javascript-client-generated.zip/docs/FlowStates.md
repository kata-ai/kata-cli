# Zaun.FlowStates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**State**](State.md) |  | [optional] 


