# Zaun.StateAction

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **String** |  | [optional] 
**method** | **String** |  | [optional] 
**condition** | **String** |  | [optional] 
**options** | **Object** |  | [optional] 


