# Zaun.ProcessedMessage

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**intent** | **String** |  | [optional] 
**attributes** | **Object** |  | [optional] 


