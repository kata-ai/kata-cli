# Zaun.Nlu

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**process** | **String** |  | [optional] 
**method** | **String** |  | [optional] 
**options** | **Object** |  | [optional] 


