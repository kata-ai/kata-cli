# Zaun.FlowMethods

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | [**Method**](Method.md) |  | [optional] 


