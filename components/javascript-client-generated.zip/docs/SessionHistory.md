# Zaun.SessionHistory

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flow** | **String** |  | [optional] 
**timestamp** | **Number** |  | [optional] 


